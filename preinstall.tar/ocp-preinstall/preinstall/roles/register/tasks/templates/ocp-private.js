[OpenShift]
baseurl = {{rhel_yum_repo_server}}
gpgcheck = 0
enabled = 1

